#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include"decode.h"

OperationType check_operation_type(char *arg);
//collecting comman line argumnets in main
int main(int argc, char*argv[])
{
//checking if valid number of arguments are passed or not
if(argc<3)
    {
        printf("Pass atleast 3 Arguments\nINFO:./a.out -e/-d secret.txt/stego.bmp\nEncoding not possible\n");
        return 0;
    }
   
   //function to check encode operation or decode operation
   OperationType ret =check_operation_type(argv[1]);//call function, address of -e string is passed
   if(ret == e_encode)
   {
    //check whether minimum 4 arguments are passed to do encoding
    if(argc<4)
    {
        printf("pass atleast 4 arguments");//error message
        printf("INFO:./a.out -e secret.txt stego.bmp");
        return 0;
    }
    
    EncodeInfo encInfo;
    printf("Do encoding\n");

    //validations to check whether passed arguments are valid or not to do encoding
    if(read_and_validate_encode_args(argv, &encInfo)==e_success)//status, function call
    {
        printf("Read and validation executed successfully\n");
        if(do_encoding(&encInfo)==e_success)
        {
           
            printf("ENCODING  is DONE  SUCCESSFULLY\n");
        }
        else
        {
            printf("encoding is not possible");
        }
    }
    else
    {
    printf("encoding not possible\n");//stop the process
    }

    }
   
   else if(ret==e_decode)
   {
    if(argc<3)
    {
        printf("pass atleast 3 arguments");//error message
        printf("INFO:./a.out -d stego.bmp");
        
        return 0;
    }
    DecodeInfo decInfo;

    printf("Do decoding\n");
    //validations to check whether passed arguments are valid or not to do decoding
    if(read_and_validate_decode_args(argv, &decInfo)==d_success)//status, function call
    {
        printf("Read and validation executed successfully\n");
        if(do_decoding(&decInfo)==d_success)
        {
           
            printf("DECODING  is DONE  SUCCESSFULLY\n");
        }
        else
        {
            printf("error");
        }
    }
}
   
   else
   {
    printf("Pass the first argument as -e or -d to do encoding or decoding");
   }
   return 0;
}
//function to check whether argv[1] is -e or -d
OperationType check_operation_type(char *arg)//collecting -e address
{
    //check if argv is -e or not
    if(strcmp(arg, "-e")==0)
    {
        //if it is -e
        return e_encode;
     
    }
    //check if argv is _d or not
   else if(strcmp(arg, "-d")==0)
   {
        //if it is -d
        return e_decode;
   }
    
   else
        return e_unsupported;
}


