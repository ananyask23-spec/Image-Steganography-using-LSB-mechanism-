#include <stdio.h>
#include "decode.h"
#include "types.h"
#include "common.h"
#include<string.h>

//opening stego image to read out the secret data
Status open_file_(DecodeInfo *decInfo)
{
    // Src Image file
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");//to read the image data like headers, pixel data, becz we can't modify original data
    // Do Error handling
    if (decInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");//perror() prints the string "fopen", followed by : 
      // and then the system error message corresponding to errno.
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);

    	return d_failure;
    }
    return d_success;
}
//read and validation 
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    //step 1: check if argv[2] is .bmp file or not, if yes go to step 2, if not go to step 3
    if(strstr(argv[2], ".bmp")!=NULL)
    {
    //step 2: STORE THE STEGO_IMAGE IN decInfo that is stego_image_fname
    decInfo->stego_image_fname=argv[2];//store beecz both are pointer pointing to same address
    }
    else
    {
    //step 3 : print the error msg and return e_failure
    printf("Image is no bmp file\n");
    return d_failure;
    }
    //check if argument 3 passed or not
    if(argv[3]!=NULL)
    {
        {
           //store the file name in decode__file_name
           strcpy(decInfo->decode_file_name, argv[3]);// store given gile name
        }
    }
        else
             
      {
    printf("Output image not provided, Defaulting to decode\n");
    strcpy(decInfo->decode_file_name, "decoded");//default file name if not passed
      }
      return d_success;
    
}
//decodeing magic string
Status decode_magic_string(FILE *fptr_stego_image)
{  
   //create array to store magic string
    char magic_str[3];// 2 for *#, 1 for '0\'//store the magic string
    fseek(fptr_stego_image, 54, SEEK_SET);//from begining leave 54 bytes becz header
    
    for(int i=0;i<2;i++)//2 time loop run, 1st time to decode #, 2nd time to *
    {
    //calling decode_byte_from_lsb to decode a byte from LSB of an array, and store each byte in an array
    magic_str[i]=decode_byte_from_lsb(fptr_stego_image);
    }
    magic_str[2]='\0';
    //comaparing decoded magic string with alreadyy defined magic string as MACRO
    if(strcmp(magic_str, MAGIC_STRING)==0)
    {
        printf("magic strings are same\n");
        printf("decoded magic string: %s\n", magic_str);
        return d_success;
    }
    else
    {
    printf("magic strings are not same\n");
      return d_failure; 
    }
   
}
//function to decode_byte_from_lsb
Status decode_byte_from_lsb(FILE *fptr)
{
  char ch=0;//initialize the character with zero
  char secret_buffer[8];
  //read 8 bytes from stego image
  fread(secret_buffer, 8, 1, fptr);
  for(int i=0;i<8;i++)
   {
    //operation to get LSB bit from each byte and make 1 character byte
     ch=((secret_buffer[i]&1 )<<(7-i)) | ch;
   }
   return ch;//return the character
}
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
char size_extn[32];
//read 32 bytes from stego image
fread(size_extn, 32, 1, decInfo->fptr_stego_image);
//calling decode_extension_size_from_lsb and store each byte in an array
decInfo->extn_size=decode_size_from_lsb(size_extn);
//printing the extension size
printf("Extension size: %d\n", decInfo->extn_size);
return d_success;
}
  
Status decode_size_from_lsb(char*size_extn)
{
   //int ch;
    uint32_t size=0;//initialize the integer with zero
   for(int i=0;i<32;i++)
   {
    //operation to get a lsb bit from each byte and make a size
    size=((size_extn[i] & 1 )<<(31-i)) | size;
   
   }
   return size;//return the size
}
//function to decode secret file extension
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
  //char file_extn[extn_size+1];//size + null
  //loop run till extension size
  for(int i=0;i<decInfo->extn_size;i++)
    {
      //call decode_byte_from_lsb and store it in one array
    decInfo->secret_file_extn[i]=decode_byte_from_lsb(decInfo->fptr_stego_image);
    }
    decInfo->secret_file_extn[decInfo->extn_size]='\0';
    
        printf("decoded file extension:%s\n", decInfo->secret_file_extn);
        return d_success;
 }
 //function to open secret file
Status secret_file_open(DecodeInfo *decInfo)
{
  // output file 
    decInfo->fptr_decode_file= fopen(decInfo->decode_file_name, "w");//to read the image data like headers, pixel data, becz we can't modify original data
    // Do Error handling
    if (decInfo->fptr_decode_file == NULL)
    {
    	perror("fopen");//perror() prints the string "fopen", followed by : 
      // and then the system error message corresponding to errno.
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->secret_file_extn);

    	return d_failure;
    }
    return d_success;
  }
  //function to decode secret file size
    Status decode_secret_file_size(DecodeInfo *decInfo)
    {

      //array to store 32 bytes
       char file_size[32];
       //read 32 bytes from stego image
       fread(file_size, 32, 1, decInfo->fptr_stego_image);
       //calling decode_file_size_from_lsb and store each byte in an array
       decInfo->size_secret_file=decode_size_from_lsb(file_size);
       //printing secret file size
       printf("secret file size: %u\n", decInfo->size_secret_file);
       return d_success;
    }
    //function call to decode secret file data
Status decode_secret_file_data(DecodeInfo *decInfo)
{
//loop run till secret file size
for(int i=0;i<decInfo->size_secret_file;i++)//2 time loop run, 1st time to decode #, 2nd time to *
    {
    char secret_file_data=decode_byte_from_lsb(decInfo->fptr_stego_image);
    //write secret file data to output file by one by at a time
    fwrite(&secret_file_data, 1, 1, decInfo->fptr_decode_file);
    }
    return d_success;
}


//function to call all other functions
Status do_decoding(DecodeInfo *decInfo)//this function definition is contain only function calls
   {
   //function call to open stego imaage
    if(open_file_(decInfo)==d_failure)//pass the structure addresss not pass pointer address which stores the structure address, let ptr=1000, contain 500 which is structure address, if we pass& the it pass pointer addres therefore pass without &
      
      {
        //print the  error msg
        printf("decoding not possible");
        return d_failure;
      }
      else
      {
        printf("Opened succesfully\n");
      }
    //function call to decode magic string
   if(decode_magic_string(decInfo->fptr_stego_image)==e_failure)//access structure members through a pointer, any changes you make affect the original structure.
    {
      printf("unable to decode magic string\n");
      return d_failure;
    }
  else
    {
    printf("Magic string decoded succesfully\n");

    }
    //function call to decode secret file extension size
 if(decode_secret_file_extn_size(decInfo)==e_failure)
{
printf("unable to decode secrete file extension size\n");
return  d_failure;
}
else
{
 printf("secret file extension size decoded succesfully\n");
}
//function call to decode secret file extension
if(decode_secret_file_extn(decInfo)==d_failure)
{
  //print error mag
  printf("unable to decode secrete file extension");
  return d_failure;
}
else
{
  printf("secret file extension decoded succesfully\n");
  printf("concatinating file name with its extension\n");
  //concatinating the file name with its extension
  strcat(decInfo->decode_file_name, decInfo->secret_file_extn);
  //printing the output file name
  printf("output file: %s\n", decInfo->decode_file_name);
  
}
// function call to open secret file
if(secret_file_open(decInfo)==d_failure)//pass the structure addresss not pass pointer address which stores the structure address, let ptr=1000, contain 500 which is structure address, if we pass& the it pass pointer addres therefore pass without &
      
      {
        //print the  error msg
        printf("decoding not possible");
        return d_failure;
      }
      else
      {
        printf("output secret file Opened succesfully\n");
      }
      //function call to decode secret file size
if(decode_secret_file_size(decInfo) == d_failure)
{
    printf("unable to encode secret file size");//error message if fails
    return d_failure;
}
else
{
    printf("secret file size encoded successfully\n");
}
//function call to decode secret file data
if(decode_secret_file_data(decInfo)==d_failure)//calling to decode secret file data
{
  printf("unable to encode secret file data");
}
else
{
  printf("secret file data decoded successfully\n");//success meassage
}
return d_success;
}


    
     
   