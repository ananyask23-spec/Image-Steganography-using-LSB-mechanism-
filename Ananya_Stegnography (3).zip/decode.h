#ifndef DECODE_H
#define DECODE_H

#include "types.h" 
// Contains user defined types
#include<stdint.h>

/* 
 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
   
    /* Secret File Info */
    
    
    char extn_secret_file[MAX_FILE_SUFFIX];//store the
    char secret_data[MAX_SECRET_BUF_SIZE];
    uint size_secret_file;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;//file pointer to open stego image
    FILE *fptr_decode_file;//file pointer to open decode_file
    



    //char decode_file_name[100];//to store secrete file name
    char decode_file_name[100];
    int extn_size;//to store secrete file extension size
    char secret_file_extn[20];//to store secret file extension
    
    
    

} DecodeInfo;


/* Decoding function prototype */

/* Check operation type */
OperationType check_operation_type(char *arg);//passing -e address which is 1 d array, so pointer is enough, argv[1]

/* Read and validate Decode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);//EncodeInfo *enInfo= structure pointer, structre address is passed becz if it is valid we have to store it is structure again

/* Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
Status open_file_(DecodeInfo *decInfo);

/* Store Magic String */
Status decode_magic_string(FILE *fptr_stego_image);

/*Decode secret file extenstion size */
Status decode_secret_file_extn_size(DecodeInfo *decInfo);

/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo);

/* Decode a byte from LSB of image data array */
Status decode_byte_from_lsb(FILE *fptr);

/* Decode secret file extenstion */
Status decode_secret_file_extn(DecodeInfo *decInfo);

Status secret_file_open(DecodeInfo *decInfo);

/* Decode secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo);

/* Decode a size from LSB of image data array */
Status decode_size_from_lsb(char *size_extn);

/* Get file size */
uint get_file_size(FILE *fptr);
#endif
