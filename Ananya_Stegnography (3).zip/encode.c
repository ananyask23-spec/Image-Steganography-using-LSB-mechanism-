#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include<string.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
    //Width = 1024 → Each row of the image contains 1024 pixels.

    //Height = 768 → There are 768 such rows (from top to bottom).
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");//to read the image data like headers, pixel data, becz we can't modify original data
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");//perror() prints the string "fopen", followed by : 
      // and then the system error message corresponding to errno.
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");//append doesnot erase old data, read , write both, if file not exist it will create
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }
    
    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");//diffrent from src image becz we are putting data in it.
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    //step 1: check if argv[2] is .bmp file or not, if yes go to step 2, if not go to step 3
    if(strstr(argv[2], ".bmp")!=NULL)
    {
    //step 2: STORE THE SRC_IMAGE IN encInfo that is src_image_fname
    encInfo->src_image_fname=argv[2];//store beecz both are pointer pointing to same address
    }
    else
    {
    //step 3 : print the error msg and return e_failure
    printf("Image is no bmp file\n");
    return e_failure;
    }
    //step 4: check if argv[3] is .txt file, if yes goto step 5, if not goto step 6
    if(strstr(argv[3], ".txt")|| strstr(argv[3], ".c")||strstr(argv[3], ".sh")||strstr(argv[3], ".py"))
    {
    encInfo->secret_fname=argv[3];//echo "My password is ANANYA ;)" > secret.txt
    
    //step 5: store the secret_file name in secret_fname(access by structure)
    //store the extension in extension_sec_file
    //strrchr checks last occurence of . becz after last dot only extension present

        char *dot=strrchr(argv[3], '.');//strrchr= string reverse(from end) character, last dot in the file 
        if(dot!=NULL)//dot==NUll means not found, !NULl means found, becz some files not contains dot only
        {
           strcpy(encInfo->extn_secret_file, dot);// this is not pointer it is an array, arrays cannot be assigned(=) directly we have to copy the characterto array
        }
        else
        {
            printf("No extension is found in secrete file");
            return e_failure;
        }
      }
      else
    {
       printf("ERROR: Secret file must have .txt extension\n");
       return e_failure;
    }
     //check if argv[4] is passed or not
    if(argv[4]!=NULL)
    {
        //check file is .bmp or not 
        if(strstr(argv[4], ".bmp")!=NULL)
        {
           //store the file name in stego_image_fname
           
           encInfo->stego_image_fname=argv[4];
        }

        else
        {
          printf("Invalid output image format. Defaulting to stego.bmp\n");
           return -1;
        }
      }

        else
      {
    // defaulting to stego.bmp if user not provided optional image  
    printf("Output image not provided. Defaulting to stego.bmp\n");
    encInfo->stego_image_fname="stego.bmp";
      }
      return e_success;
    
}

//function to copy reaming image data
Status copy_remaining_img_data(FILE *src, FILE *stego)
{
char ch;
//read byte by byte till EOF
while(fread(&ch, 1, 1, src)>0)//end of file is -1, therefore >0
{
  fwrite(&ch, 1, 1, stego);//writing to stego image
}
return e_success;
}

//function to encode secret file data
Status encode_secret_file_data(EncodeInfo *encInfo)
{
  char data[encInfo->size_secret_file];//based on file size only file data array is created.
  //becz file pointer present at EOF
  rewind(encInfo->fptr_secret);
  //read the secret data and stored into the data[arrray name]
  fread(data, 1, encInfo->size_secret_file, encInfo->fptr_secret);//(destination_arry, size of eachelement, numberofbytes to read, filepointer)
  //store the null at last of string
  //call the data_image
  encode_data_to_image(data, encInfo->size_secret_file, encInfo->fptr_src_image, encInfo->fptr_stego_image);
  //encode_data_to_image(data, encInfo->size_secret_file, pass two file pointers that is src, stego);
  return e_success;
}

//function to encode secret file size
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
  //calling the function encode_secret_file_extn_size and returning 
return encode_secret_file_extn_size(file_size, encInfo);
}

//function to encode secret file extension
Status encode_secret_file_extn(char *file_extn,   EncodeInfo *encInfo)
{
  //calling the function encode_data_to_image and returning
  return encode_data_to_image(file_extn, strlen(file_extn), encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

//function to encode secret file extension size
Status encode_secret_file_extn_size(long _extn_size, EncodeInfo *encInfo)
{
char image_buffer[32];
//read 32 bytes from the src
fread(image_buffer, 32, 1, encInfo->fptr_src_image);
//call the size_to_lsb

encode_size_to_lsb(_extn_size, image_buffer);
//write 32 bytes to the stego
fwrite(image_buffer, 32, 1, encInfo->fptr_stego_image);
return e_success;
}


//encoding extension size and file size
Status encode_size_to_lsb(uint32_t data, char *image_buffer)//int becz size is integer that is 32
{
  for(int i=0;i<32;i++)
  {
   //step 1: get msb bit from data
  //step 2: clear lsb bit in image buffer
  //set the bit that is step 1 | step 2
  
   image_buffer[i] =(image_buffer[i] & (~1)) | ((data & (1 << (31 - i))) >> (31 - i));

  }
   return e_success;
}




//encoding magic string, file extension, file data
Status encode_byte_to_lsb(char data, char *image_buffer)
{
   for(int i=0;i<8;i++)
   {
  //step 1: get msb bit from data 
  //step 2: clear lsb bit in image buffer
  //set the bit that is step 1 | step 2
  image_buffer[i] =(image_buffer[i] & (~1)) | ((data & (1 << (7 - i))) >> (7 - i));

   
   }
  return e_success;

}
   //function to encode magic string, extension, file data
   Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
   {
     
     char image_buffer[8];
     for(int i=0;i<size;i++)
     {
      //step 1: read the 8 bytes from src_image
      fread(image_buffer, 8, 1, fptr_src_image);
      //step 2: call the encode_byte_to_lsb (data[0], image_buffer);//data[i]
      encode_byte_to_lsb(data[i],image_buffer);
      //write the 8bytes to stego
      fwrite(image_buffer, 8, 1, fptr_stego_image);
     }
      return e_success;
    }
  
  //encoding magic string
   Status encode_magic_string(EncodeInfo *encInfo, char *magic_string)
    {
      
      return encode_data_to_image(magic_string, strlen(magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image);
      //strlen(magic_string)=size
    }
    
    
    //copying first 54 byte from src image  to dest image
     Status copy_bmp_header(FILE *src, FILE *stego)
   {
      rewind(src);//to place the cursor back to  start of the file becz it is in 26 th byte, when we finding height of bmp src file
      char buffer[54];//array to store 54 bytes
      //read 54 bytesfrom src and store into buffer
      if (fread(buffer, 54, 1, src) != 1)// 1 becz 1 block of data contains 54 bytes.
    {
        printf("Error: Failed to read BMP header from source image\n");
        return e_failure;
    }
    //write 54 bytes into dest 
    if (fwrite(buffer, 54, 1, stego) != 1)//
    {
        printf("Error: Failed to write BMP header to destination image\n");
        return e_failure;
    }

    return e_success;
}
    

    //to get secrete file size
    uint get_file_size(FILE *fptr)
    {
      rewind(fptr);
      //move the cursor to the end of file
      fseek(fptr, 0, SEEK_END);
      //return the pos[ftell]
       return ftell(fptr);
    }

    //function to check capacity that src file is greater to hide all secret data of secret file
     Status check_capacity(EncodeInfo *encInfo)
    {

      uint image_capacity=get_image_size_for_bmp(encInfo->fptr_src_image);//to know src image size

      encInfo->size_secret_file=get_file_size(encInfo->fptr_secret);//store the file size in structure member we use structure memeber becz it is public out of scope also we can access
      

      //header + magic string +  secret file_extension size + secret_file_extension + sec_file_size +sec_file_content
      if(image_capacity > 54 + (strlen(MAGIC_STRING)* 8)+ 32 + strlen(encInfo->extn_secret_file)* 8 + 32 + (encInfo->size_secret_file*8))
        {
          return e_success;   //first 32=extension size 
        }
        else
        {
          return e_failure;
        }
      }
      //function to call all other functions which involved in decoding process
   Status do_encoding(EncodeInfo *encInfo)//this function definition is contain only function calls
   {

    //function to open the files
      if(open_files(encInfo)==e_failure)//pass the structure addresss not pass pointer address which stores the structure address, let ptr=1000, contain 500 which is structure address, if we pass& the it pass pointer addres therefore pass without &
      
      {
        //print the  error msg
        printf("encoding not possible");
        return e_failure;
      }
      else
      {
        printf("Opened succesfully\n");
      }
    
      //function call to check capacity
      if(check_capacity(encInfo)==e_failure)
      {
        printf("encoding not possible");
        return e_failure;
      }
      else
      {
        printf("Check capacity done successfully\n");
      }

    //function to encode bmp header 54 bytes from src image
     if(copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image)==e_failure)
     {
      printf("cannot copy header from src image to dest image");
      return e_failure;
     }
    else
    {
      printf("Header successfully copied\n");
    }

     //function to encode magic string
   if(encode_magic_string(encInfo, MAGIC_STRING)==e_failure)
    {
      printf("unable to encode magic string");
      return e_failure;
    }
  else
    {
    
      printf("Magic string encoded succesfully\n");

    }
//function to encode secret file extension size
if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo)==e_failure)
{
printf("unable to encode secrete file extension size");
return  e_failure;
}
else
{
 printf("file extension size encoded successfully\n");
}
//function to encode secret file extension 
if(encode_secret_file_extn(encInfo->extn_secret_file, encInfo)==e_failure)
{
  //print error mag
  printf("unable to encode secrete file extension");
  return e_failure;
}
else
{
  printf("secret file extension encoded succesfully\n");
}
//function to encode secret file size
if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure)
{
    printf("unable to encode secret file size");
    return e_failure;
}
else
{
    printf("secret file size encoded successfully\n");
}
//function to encode secret file data
if(encode_secret_file_data(encInfo)==e_failure)
{
  printf("unable to encode secret file data");
}
else
{
  printf("secret file data encoded successfully\n");
}

//function to encode remaining image data
if(copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image)==e_failure)
{
    printf("Error:Unable to encode remaining image data");
    return e_failure;
}
else
{
printf("Remaining image data encoded successfully\n");
}
return e_success;
}

    
     
   